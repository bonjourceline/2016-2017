# DeviceOrientation
iOS中关闭屏幕旋转功能时判断屏幕方向

利用螺旋仪运动模块实现
需引入CoreMotion.frameWork框架
![效果图](http://wx3.sinaimg.cn/mw690/c320c33egy1fcz3pb9g8lj20ku112mxs.jpg)
