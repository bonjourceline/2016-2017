# GetUUID
iOS可用的uuid获取  重新安装应用还是第一次初始化的那个唯一标识码
