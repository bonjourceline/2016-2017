//
//  OLImageStrictResponseSerializer.h
//  OLImageViewDemo
//
//  Created by Romans Karpelcevs on 16/06/14.
//  Copyright (c) 2014 Onda Labs. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <AFNetworking/AFURLResponseSerialization.h>

@interface OLImageStrictResponseSerializer : AFImageResponseSerializer

@end
