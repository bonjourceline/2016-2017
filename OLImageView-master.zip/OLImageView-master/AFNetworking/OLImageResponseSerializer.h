//
//  OLImageResponseSerializer.h
//  OLImageViewDemo
//
//  Created by Romans Karpelcevs on 29/05/14.
//  Copyright (c) 2014 Onda Labs. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <AFNetworking/AFURLResponseSerialization.h>

@interface OLImageResponseSerializer : AFImageResponseSerializer

@end
